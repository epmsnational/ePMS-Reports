module.exports = <%= metadata %>;
